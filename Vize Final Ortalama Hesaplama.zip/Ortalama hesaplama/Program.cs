﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ortalama_hesaplama
{
    internal class Program
    {
        static void Main(string[] args)
        {

        a:
            double vizeYuzde, finalYuzde, vizeNot, finalNot, vizeSon, finalSon, ortalama;
            string islem;
            Console.Write("Vize Yüzdeliğini Giriniz: ");
            vizeYuzde=Convert.ToInt32(Console.ReadLine());

            Console.Write("Final Yüzdeliğini Giriniz: ");
            finalYuzde=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("**************************************************");

            Console.Write("Vize Notunuzu Giriniz: ");
            vizeNot=Convert.ToInt32(Console.ReadLine());

            Console.Write("Final Notunuzu Giriniz: ");
            finalNot=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("**************************************************");

            /////////////////////////////////////////////////////

            vizeYuzde = (vizeYuzde / 100);
            finalYuzde= (finalYuzde / 100);

            vizeSon = (vizeNot*vizeYuzde);
            finalSon= (finalNot*finalYuzde);

            ortalama = (vizeSon+finalSon);


            Console.WriteLine("Ders Ortalamanız: " + ortalama);
            Console.WriteLine("**************************************************");

            Console.WriteLine("Başka Bir İşlem Yapacakmısınız?");
            Console.WriteLine("E // H");
            islem=Convert.ToString(Console.ReadLine());

            if ((islem == "E")||(islem == "e"))
            {
                Console.WriteLine("**************************************************");
                Console.Clear();
                goto a;
            }
            else
            {
                Console.WriteLine("Görüşmek üzere....");
                Console.WriteLine("orionn.com.tr \n@kaanlatinler");
            }

            Console.ReadKey();
        }
    }
}
